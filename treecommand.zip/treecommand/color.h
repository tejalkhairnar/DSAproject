void black();
void red();
void green();
void yellow();
void blue();
void purple();
void cyan();
void white();
void reset();


void file_size( char *fname );
void file_permission( char *fname );
void file_time( char *fname );
void uid_num();
void gid_num();
int str_str(char *str, char *ch);